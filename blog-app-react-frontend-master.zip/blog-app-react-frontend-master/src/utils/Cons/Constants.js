export const apiHost = "https://blog-backend-rails.herokuapp.com/api/v1";
export const baseUrl = "https://blog-backend-rails.herokuapp.com";
// export const apiHost = "http://localhost:3001/api/v1";
// export const baseUrl = "http://localhost:3001";
