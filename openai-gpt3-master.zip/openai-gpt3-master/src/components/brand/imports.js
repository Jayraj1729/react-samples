import google from "../../assets/google.png";
import atlassian from "../../assets/atlassian.png";
import slack from "../../assets/slack.png";
import dropbox from "../../assets/dropbox.png";
import shopify from "../../assets/shopify.png";

export {
    google,
    slack,
    atlassian,
    dropbox,
    shopify
}