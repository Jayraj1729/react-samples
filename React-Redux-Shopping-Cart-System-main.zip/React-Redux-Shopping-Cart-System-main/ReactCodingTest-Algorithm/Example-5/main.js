/*Example 5:
  Input: nums1 = [2], nums2 = []
  Output: 2.00000 */
