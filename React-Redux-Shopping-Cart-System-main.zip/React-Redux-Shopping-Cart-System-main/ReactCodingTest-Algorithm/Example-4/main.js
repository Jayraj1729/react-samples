/*Example 4:
  Input: nums1 = [], nums2 = [1]
  Output: 1.00000 */
