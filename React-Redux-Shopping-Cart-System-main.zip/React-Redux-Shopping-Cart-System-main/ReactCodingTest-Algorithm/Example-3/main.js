/*Example 3:
  Input: nums1 = [0,0], nums2 = [0,0]
  Output: 0.00000 */
